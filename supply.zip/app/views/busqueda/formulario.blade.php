
<div class="busqueda">

<img src="{{asset('images/home/arme_su_cadena_small.png')}}" class="titulo_busqueda">
<div class="salto_linea"></div>


<form class="form-horizontal form_home_buscar" id="busqueda">
	<div class="campos_busq">

	  <div class="form-group">
	    <label for="perfil" class="col-xs-2 control-label">
	    	<img src="{{asset('images/home/uno.png')}}" alt="">
	    </label>
	    <div class="col-xs-10">
	      <select name="perfil" id="perfil"  class="form-control">
	      	<option value="">Importar</option>
	      	<option value="">Transportar</option>
	      	<option value="">SIAS</option>
	      </select>
	    </div>
	  </div>	

	  <div class="salto_linea"></div>

	  <div class="form-group">
	    <label for="categoria" class="col-xs-2 control-label">
	    	<img src="{{asset('images/home/dos.png')}}" alt="">
	    </label>
	    <div class="col-xs-10">
	      <select name="categoria" id="categoria"  class="form-control">
	      	<option value="">Categoría</option>
	      	<option value="">Auto</option>
	      	<option value="">Agricultura</option>
	      </select>
	    </div>
	  </div>	


	  <div class="form-group">
	    <label for="producto" class="col-xs-2 control-label num_form">
	    	<img src="{{asset('images/home/tres.png')}}" alt="">
	    </label>
	    <div class="col-xs-10">
	      <input type="text" class="form-control" id="producto" placeholder="PRODUCTO">
	    </div>
	  </div>

	  <div class="salto_linea"></div>

	  <div class="form-group">
	    <label for="region" class="col-xs-2 control-label">
	    	<img src="{{asset('images/home/cuatro.png')}}" alt="">
	    </label>
	    <div class="col-xs-10">
	      <select name="region" id="region" class="form-control">
	      	<option value="">Región</option>
	      	<option value="">Centro América</option>
	      	<option value="">Europa</option>
	      </select>
	    </div>
	  </div>

	<div class="salto_linea"></div>
	  <div class="form-group">
	    <label for="destino" class="col-xs-2 control-label num_form">
	    	<img src="{{asset('images/home/cinco.png')}}" alt="">
	    </label>
	    <div class="col-xs-10">
	      <select name="destino" id="destino"  class="form-control">
	      	<option value="">PAÍS DE DESTINO</option>
	      	<option value="">Colombia</option>
	      	<option value="">Ecuador</option>
	      	<option value="">Perú</option>
	      </select>
	    </div>
	  </div>

	  <div class="form-group">
	    <label for="origen" class="col-xs-2 control-label num_form">
	    	<img src="{{asset('images/home/seix.png')}}" alt="">
	    </label>
	    <div class="col-xs-10">
	      <select name="origen" id="origen" class="form-control">
	      	<option value="">PAÍS ORIGEN</option>
	      	<option value="">Colombia</option>
	      	<option value="">Ecuador</option>
	      	<option value="">Perú</option>
	      </select>
	    </div>
	  </div>

	  <div class="salto_linea"></div>	  	  	
	  <button class="btn-borde btn-borde-n">BUSCAR</button>
	</div>
</form>
</div>
<script>
	$('#sites input:radio').addClass('input_hidden');
	$('#sites label').click(function() {
	    $(this).addClass('selected').siblings().removeClass('selected');
	});
</script>

{{HTML::style('css/busqueda_small.css')}}
{{HTML::script('js/jquery.ddslick.min.js')}}

