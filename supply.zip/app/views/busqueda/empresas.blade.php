<div class="espacio_empresa">
	<img src="{{asset('images/cadena/comprador.png')}}">
</div>

<div class="boton_conectar" style="display:none">
	<p>&nbsp;</p>
</div>

<div class="head_empresa">
	<h1>Comprador</h1>
</div>
<div class="lista-empresas"> 
	

<div class="row post_empresa" id="post_empresa1">
	<p class="anuncio_producto">
	  <i class="fa fa-bullhorn"></i> ANUNCIOS
	</p>
	<div class="col-xs-3">
		<img src="{{asset('images/productos/zapato1.png')}}" id="product_img1">
	</div>
	<div class="col-xs-7">
		<h1 class="titulo_product1">E-Zapato-1</h1>
		<ul class="r_dtalles_producto">
			<li>Región - Ubicación</li>
			<li>Cantidad disponible</li>
			<li>XX mín XX máx</li>
			<li>Términos de pago</li>
		</ul>
	</div>	
	<div class="col-xs-2">
		<button class="btn-borde btn-borde-ai btn_selec" id="empresa1">
			Seleccionar
		</button>	
		<br>
		<img src="{{asset('images/productos/start.png')}}">

		<div class="dropdown">
		  <a class="link" id="dLabel" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		    <span class="caret"></span>
		  </a>
			<ul class="dropdown-menu menu_acciones_producto" role="menu" aria-labelledby="drop3">
				<li role="presentation"><a role="menuitem" tabindex="-1" href="#">Esconder</a></li>
				<li role="presentation"><a role="menuitem" tabindex="-1" href="#">Another action</a></li>
			</ul>
		</div>		
	</div>
</div>

<div class="row post_empresa" id="post_empresa2">
	<div class="col-xs-3">
		<img src="{{asset('images/productos/zapato2.png')}}" id="product_img2">
	</div>
	<div class="col-xs-7">
		<h1 class="titulo_product2">E-Zapato-2</h1>
		<ul class="r_dtalles_producto">
			<li>Región - Ubicación</li>
			<li>Cantidad disponible</li>
			<li>XX mín XX máx</li>
			<li>Términos de pago</li>
		</ul>
	</div>	
	<div class="col-xs-2">
		<button class="btn-borde btn-borde-ai btn_selec" id="empresa2">
			Seleccionar
		</button>	
		<br>
		<img src="{{asset('images/productos/start.png')}}">

		<div class="dropdown">
		  <a class="link" id="dLabel" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		    <span class="caret"></span>
		  </a>
			<ul class="dropdown-menu menu_acciones_producto" role="menu" aria-labelledby="drop3">
				<li role="presentation"><a role="menuitem" tabindex="-1" href="#">Esconder</a></li>
				<li role="presentation"><a role="menuitem" tabindex="-1" href="#">Another action</a></li>
			</ul>
		</div>		
	</div>
</div>

<div class="row post_empresa" id="post_empresa3">
	<div class="col-xs-3">
		<img src="{{asset('images/productos/zapato3.png')}}" id="product_img3">
	</div>
	<div class="col-xs-7">
		<h1 class="titulo_product3">E-Zapato-3</h1>
		<ul class="r_dtalles_producto">
			<li>Región - Ubicación</li>
			<li>Cantidad disponible</li>
			<li>XX mín XX máx</li>
			<li>Términos de pago</li>
		</ul>
	</div>	
	<div class="col-xs-2">
		<button class="btn-borde btn-borde-ai btn_selec" id="empresa3">
			Seleccionar
		</button>	
		<br>
		<img src="{{asset('images/productos/start.png')}}">

		<div class="dropdown">
		  <a class="link" id="dLabel" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		    <span class="caret"></span>
		  </a>
			<ul class="dropdown-menu menu_acciones_producto" role="menu" aria-labelledby="drop3">
				<li role="presentation"><a role="menuitem" tabindex="-1" href="#">Esconder</a></li>
				<li role="presentation"><a role="menuitem" tabindex="-1" href="#">Another action</a></li>
			</ul>
		</div>		
	</div>
</div>

<div class="row post_empresa" id="post_empresa4">
	<div class="col-xs-3">
		<img src="{{asset('images/productos/zapato4.png')}}" id="product_img4">
	</div>
	<div class="col-xs-7">
		<h1 class="titulo_product4">E-Zapato-4</h1>
		<ul class="r_dtalles_producto">
			<li>Región - Ubicación</li>
			<li>Cantidad disponible</li>
			<li>XX mín XX máx</li>
			<li>Términos de pago</li>
		</ul>
	</div>	
	<div class="col-xs-2">
		<button class="btn-borde btn-borde-ai btn_selec" id="empresa4">
			Seleccionar
		</button>	
		<br>
		<img src="{{asset('images/productos/start.png')}}">

		<div class="dropdown">
		  <a class="link" id="dLabel" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		    <span class="caret"></span>
		  </a>
			<ul class="dropdown-menu menu_acciones_producto" role="menu" aria-labelledby="drop3">
				<li role="presentation"><a role="menuitem" tabindex="-1" href="#">Esconder</a></li>
				<li role="presentation"><a role="menuitem" tabindex="-1" href="#">Another action</a></li>
			</ul>
		</div>		
	</div>
</div>

<div class="row post_empresa" id="post_empresa5">
	<div class="col-xs-3">
		<img src="{{asset('images/productos/zapato5.png')}}" id="product_img5">
	</div>
	<div class="col-xs-7">
		<h1 class="titulo_product5">E-Zapato-5</h1>
		<ul class="r_dtalles_producto">
			<li>Región - Ubicación</li>
			<li>Cantidad disponible</li>
			<li>XX mín XX máx</li>
			<li>Términos de pago</li>
		</ul>
	</div>	
	<div class="col-xs-2">
		<button class="btn-borde btn-borde-ai btn_selec" id="empresa5">
			Seleccionar
		</button>	
		<br>
		<img src="{{asset('images/productos/start.png')}}">

		<div class="dropdown">
		  <a class="link" id="dLabel" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
		    <span class="caret"></span>
		  </a>
			<ul class="dropdown-menu menu_acciones_producto" role="menu" aria-labelledby="drop3">
				<li role="presentation"><a role="menuitem" tabindex="-1" href="#">Esconder</a></li>
				<li role="presentation"><a role="menuitem" tabindex="-1" href="#">Another action</a></li>
			</ul>
		</div>		
	</div>
</div>

</div> <!-- / lista-empresa  -->

<script>
$( document ).ready(function() {
	
// chekea si ya se agrego una empresa de Transporte o SIAS
var data_t = $( ".espacio_transporte" ).data('ckeck');
var data_s = $( ".espacio_sias" ).data('ckeck');

	$("#empresa1").click(function(event) {

		$("#post_empresa1").addClass('activo_check').siblings().removeClass('activo_check');
		var imagen = $('#product_img1').attr('src');
		var titulo = $(".titulo_product1").text();
		$(".espacio_empresa").empty();
	    $('.espacio_empresa').append(('<img src=" '+imagen+' "> <div class="contenido_producto"><span class="tpc"> '+titulo+' </span><br><span>Comprador</span></div>'));	
	    $('.boton_conectar').show('last');

	    // chekea si ya se agrego una empresa de Transporte o SIAS
	    if ( data_t == false ) {
			$(".espacio_transporte").empty();
		    $('.espacio_transporte').append(('<img src="images/cadena/recomendado_transportador.png">'));	
		}
		if ( data_s == false ) {
			$(".espacio_sias").empty();
		    $('.espacio_sias').append(('<img src="images/cadena/recomendado_sias.png">'));	
		}		


	});

	$("#empresa2").click(function(event) {

		$("#post_empresa2").addClass('activo_check').siblings().removeClass('activo_check');
		var imagen = $('#product_img2').attr('src');
		var titulo = $(".titulo_product2").text();
		$(".espacio_empresa").empty();
	    $('.espacio_empresa').append(('<img src=" '+imagen+' "> <div class="contenido_producto"><span class="tpc"> '+titulo+' </span><br><span>Comprador</span></div>'));	
	    $('.boton_conectar').show('last');

	    if ( data_t == false ) {
			$(".espacio_transporte").empty();
		    $('.espacio_transporte').append(('<img src="images/cadena/recomendado_transportador.png">'));	
		}
		if ( data_s == false ) {
			$(".espacio_sias").empty();
		    $('.espacio_sias').append(('<img src="images/cadena/recomendado_sias.png">'));	
		}		


	});

	$("#empresa3").click(function(event) {

		$("#post_empresa3").addClass('activo_check').siblings().removeClass('activo_check');
		var imagen = $('#product_img3').attr('src');
		var titulo = $(".titulo_product3").text();
		$(".espacio_empresa").empty();
	    $('.espacio_empresa').append(('<img src=" '+imagen+' "> <div class="contenido_producto"><span class="tpc"> '+titulo+' </span><br><span>Comprador</span></div>'));	
	    $('.boton_conectar').show('last');

	    if ( data_t == false ) {
			$(".espacio_transporte").empty();
		    $('.espacio_transporte').append(('<img src="images/cadena/recomendado_transportador.png">'));	
		}
		if ( data_s == false ) {
			$(".espacio_sias").empty();
		    $('.espacio_sias').append(('<img src="images/cadena/recomendado_sias.png">'));	
		}		


	});

	$("#empresa4").click(function(event) {

		$("#post_empresa4").addClass('activo_check').siblings().removeClass('activo_check');
		var imagen = $('#product_img4').attr('src');
		var titulo = $(".titulo_product4").text();
		$(".espacio_empresa").empty();
	    $('.espacio_empresa').append(('<img src=" '+imagen+' "> <div class="contenido_producto"><span class="tpc"> '+titulo+' </span><br><span>Comprador</span></div>'));	
	    $('.boton_conectar').show('last');

	    if ( data_t == false ) {
			$(".espacio_transporte").empty();
		    $('.espacio_transporte').append(('<img src="images/cadena/recomendado_transportador.png">'));	
		}
		if ( data_s == false ) {
			$(".espacio_sias").empty();
		    $('.espacio_sias').append(('<img src="images/cadena/recomendado_sias.png">'));	
		}		


	});

	$("#empresa5").click(function(event) {

		$("#post_empresa5").addClass('activo_check').siblings().removeClass('activo_check');
		var imagen = $('#product_img5').attr('src');
		var titulo = $(".titulo_product5").text();
		$(".espacio_empresa").empty();
	    $('.espacio_empresa').append(('<img src=" '+imagen+' "> <div class="contenido_producto"><span class="tpc"> '+titulo+' </span><br><span>Comprador</span></div>'));	
	    $('.boton_conectar').show('last');

	    if ( data_t == false ) {
			$(".espacio_transporte").empty();
		    $('.espacio_transporte').append(('<img src="images/cadena/recomendado_transportador.png">'));	
		}
		if ( data_s == false ) {
			$(".espacio_sias").empty();
		    $('.espacio_sias').append(('<img src="images/cadena/recomendado_sias.png">'));	
		}		

	});	
}); // fin ready	
</script>

@section('estilos')
@parent
	{{HTML::style('css/lista_empresas.css')}}
@stop



