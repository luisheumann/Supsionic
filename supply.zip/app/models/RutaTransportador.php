<?php

class RutaTransportador extends Eloquent
{
	protected $table = 'ruta_transporte';
}
