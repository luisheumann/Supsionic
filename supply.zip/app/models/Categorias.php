<?php

class Categorias extends Eloquent
{
	protected $table = 'categorias';
}
