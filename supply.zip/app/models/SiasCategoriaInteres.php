<?php

class SiasCategoriaInteres extends Eloquent
{
	protected $table = 'sias_categoria_interes';
}
