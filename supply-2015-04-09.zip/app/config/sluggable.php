<?php
return array(
    'build_from'      => null,
    'save_to'         => 'slug',
    'max_length'      => null,
    'method'          => null,
    'separator'       => '-',
    'unique'          => true,
    'include_trashed' => false,
    'on_update'       => true,
    'reserved'        => null,
    'use_cache'       => false,
);
?>