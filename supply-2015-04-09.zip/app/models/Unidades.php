<?php

class Unidades extends Eloquent
{
	protected $table = 'unidades';
}
