<?php

class RutaExportador extends Eloquent
{
	protected $table = 'ruta_exportador';
}
