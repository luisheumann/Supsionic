<!-- MENÚ LATERAL CATGEORIAS -->
<ul class="menu-categorias-blanco">
  <li class="mc-titulo">CATEGORIAS</li>
  <li><a href="#">Agricultura y Alimentos</a></li>
  <li><a href="#">Auto y Transporte</a></li>
  <li class="active"><a href="#">Bolsos, Zapatos y Accesorios</a></li>
  <li><a href="#">Electrónica</a></li>
  <li><a href="#">Maquinaria, Piezas y Herramientas Industriales</a></li>
  <li><a href="#">Metalurgia, productos químicos, caucho y plásticos</a></li>
  <li><a href="#">Packaging, Publicidad y Oficina</a></li>
  <li><a href="#">Regalos, Deportes y juguetes</a></li>
  <li><a href="#">Salud y Bienestar</a></li>
  <li><a href="#">VER TODAS...</a></li>
  <li><a href="#">lskdlskdlsdksd...</a></li>
  <li><a href="#">Electrónica</a></li>
  <li><a href="#">Maquinaria, Piezas y Herramientas Industriales</a></li>
  <li><a href="#">Metalurgia, productos químicos, caucho y plásticos</a></li>
  <li><a href="#">Packaging, Publicidad y Oficina</a></li>
  <li><a href="#">Regalos, Deportes y juguetes</a></li>
  <li><a href="#">Salud y Bienestar</a></li>
  <li><a href="#">VER TODAS...</a></li>
  <li><a href="#">lskdlskdlsdksd...</a></li>
  <li><a href="#">Electrónica</a></li>
  <li><a href="#">Maquinaria, Piezas y Herramientas Industriales</a></li>
  <li><a href="#">Metalurgia, productos químicos, caucho y plásticos</a></li>
  <li><a href="#">Packaging, Publicidad y Oficina</a></li>
  <li><a href="#">Regalos, Deportes y juguetes</a></li>
  <li><a href="#">Salud y Bienestar</a></li>
  <li><a href="#">VER TODAS...</a></li>
  <li><a href="#">lskdlskdlsdksd...</a></li>    
</ul>
<script>
  $(document).ready(function(){
    $('.menu-categorias-blanco li').hover(function() {
      $('.menu-categorias-blanco li').removeClass('active');
    }, function() {
      $(this).not('.mc-titulo').addClass('active');
    });
  });

jQuery(document).ready(function($){
    $(window).on("load",function(){ 
        var windowHeight = $(document).height();
        console.log('Altura: '+windowHeight);
        $('.outer').css('height',windowHeight + 'px');
    });
});

jQuery(document).ready(function($){
    $(window).scroll(function(){
        var windowHeight = $(document).height();
        $('.outer').css('height',windowHeight + 'px');
    });
});  
</script>
    
