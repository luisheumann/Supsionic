@extends('layouts/default')
@section('content')

@section('title')
@parent
 ¡ Bienvenido a SupplyME !
@stop
@include('includes.header')

<div class="row home-red center-block" style="float:none">
  <div class="col-xs-3">
      @include('busqueda/formulario')
  </div>

<div class="col-xs-9">

  <div class="col-xs-4">
      @include('busqueda/empresas')
  </div>  

  <div class="col-xs-4">
      @include('busqueda/transportadores')
  </div>  

  <div class="col-xs-4">
      @include('busqueda/sias')
  </div> 
  
</div>
 

</div>



<!-- Modal Cadena   -->
<div class="modal fade" id="ModalCadena" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" style="width: 1000px">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Modal title</h4>
      </div>
      <div class="modal-body cadena_seleccionada">
        <h1>ESTA ES LA CADENA DE ABASTECIMIENTO QUE HA ELEGIDO PARA SU NEGOCIO.</h1>
        
        <div class="row contenedor_su_cadena">

          <div class="col-md-3 item_cadena" >
            <h2>
            <img src="{{asset('images/iconos_a/icon_importar.png')}}" width="25px" style="margin-top: -13px;" >
            VENDEDOR</h2>
            <div id="su_empresa_producto"></div>
          </div>

          <div class="col-md-3 item_cadena">
            <h2><img src="{{asset('images/iconos_a/icon_transportar.png')}}" width="25px"> TRANSPORTADOR</h2>
            <div id="su_transporte"></div>
          </div>

          <div class="col-md-3 item_cadena">
            <h2><img src="{{asset('images/iconos_a/icon_sias.png')}}" width="25px"> SIA</h2>
            <div id="su_sia"></div>
          </div>

          <div class="col-md-3 item_cadena">
            <h2><img src="{{asset('images/iconos_a/icon_sias.png')}}" width="25px"> PRODUCTO</h2>
            <div id="su_producto"></div>
          </div>          

        </div>

        <div class="row">
          <div class="col-md-4 col-md-offset-2">
            <a href="#">
              <img src="{{asset('images/cadena/btn_modificar.png')}}" alt="">    
            </a>            
          </div>
          <div class="col-md-4">
            <a href="#">
              <img src="{{asset('images/cadena/btn_continuar.png')}}" alt="">    
            </a>            
          </div>          
        </div>

        

      </div>
    </div>
  </div>
</div>



<!-- Modal Desea Completar perfil -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog-registro">
    <div class="modal-content-registro">
      <div class="modal-body" align="center">
        <h1>¡BIENVENIDO!</h1>
        <img src="{{asset('images/flecha.png')}}" >
        <h2>DESEA CONTINUAR COMPLETANDO SU PERFIL</h2>
        <a href="{{URL::to($slug.'/registro')}}" class="btn-borde btn-borde-n">CONTINUAR</a><br>
        <a href="#" class="btn-borde btn-borde-a" data-dismiss="modal">OMITIR</a>
      </div>
    </div>
  </div>
</div>

<script>
	$(document).ready(function(){
     $("#mostar_mi_cadena").on('click', ArmaCadena);
  });

function ArmaCadena() {

    $('#ModalCadena').modal('show');

    // chekea si ya se agrego una empresa de Transporte o SIAS
    var data_e = $( ".espacio_empresa" ).attr('data-ckeck');
    var data_t = $( ".espacio_transporte" ).attr('data-ckeck');
    var data_s = $( ".espacio_sias" ).attr('data-ckeck');
 
    // chekea si se ha seleccionado una empresa
    if ( data_e == 'true' ) {
      $("#su_empresa_producto").empty();
      var get_img = $( ".espacio_empresa img" ).attr('src');
      var get_nombre = $( ".espacio_empresa .contenido_producto .tpc" ).text();
      $('#su_empresa_producto').append(('<img src=" '+get_img+' "> <span class="tec">'+get_nombre+'</span> <img src="../public/images/fc.png"> ')); 
    }

    // chekea si se ha seleccionado una transportadora
    if ( data_t == 'true' ) {
      $("#su_transporte").empty();
      var get_img = $( ".espacio_transporte img" ).attr('src');
      var get_nombre = $( ".espacio_transporte .contenido_producto .tpc" ).text();
      $('#su_transporte').append(('<img src=" '+get_img+' "> <span class="tec">'+get_nombre+'</span>  <img src="../public/images/fc.png">')); 
    }
 
    // chekea si se ha seleccionado una SIA
    if ( data_s == 'true' ) {
      $("#su_sia").empty();
      var get_img = $( ".espacio_sias img" ).attr('src');
      var get_nombre = $( ".espacio_sias .contenido_producto .tpc" ).text();
      $('#su_sia').append(('<img src=" '+get_img+' "> <span class="tec">'+get_nombre+'</span> <img src="../public/images/fc.png">')); 
    } 
}
		
	
		

</script>
@section('estilos')
@parent
{{ HTML::style('css/main_home.css')}}
{{ HTML::style('css/home_social.css')}}
@stop

<!-- Finaliza el render de la pagina -->
@stop