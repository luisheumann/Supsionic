<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.3.0/angular.min.js"></script>

<div class="head_empresa">
	<h1>Empresas</h1>
</div>

<div ng-app="AppEmpresa">
	<div class="lista-empresas" ng-controller="EmpresaCtrl" > 
		<div class="post_empresa" ng-repeat="empresa in empresas">
			<button class="btn-borde btn-borde-ai" id="empresa<% $index %>">
				Conectar 
				<img src="{{asset('images/home/conect.png')}}">
			</button>	
			<img src="{{asset('<% empresa.imagen %>')}}">
			<p>
				<span><% empresa.nombre %></span>
				<% empresa.descripcion %>
			</p>
			<div class="clearfix"></div>
		</div>
	</div>
</div>


<script>
var AppEmpresa = angular.module('AppEmpresa', []);

AppEmpresa.config(function($interpolateProvider) {
  $interpolateProvider.startSymbol('<%');
  $interpolateProvider.endSymbol('%>');
});


AppEmpresa.controller("EmpresaCtrl", function($scope, $http) {
  $http.get('empresa.json').
    success(function(data, status, headers, config) {
      $scope.empresas = data;
    }).
    error(function(data, status, headers, config) {
      // log error
      console.log('Error');
    });
});


	$("#empresa1").click(function(event) {
		var id = $(this).attr("id");
		//var imagen = $(this).parent(".post_empresa").children("img").attr('src');
		var imagen = $(this).next().attr('src');
		console.log("click: "+id);
		console.log("imagen: "+imagen);
	});
</script>

{{HTML::style('css/lista_empresas.css')}}