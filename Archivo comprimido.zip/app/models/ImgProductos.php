<?php

class ImgProductos extends Eloquent
{
	protected $table = 'img_productos';
}


