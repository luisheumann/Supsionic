<?php

class Perfil extends Eloquent
{
	protected $table = 'perfil';
}
