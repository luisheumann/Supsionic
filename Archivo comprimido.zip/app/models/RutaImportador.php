<?php

class RutaImportador extends Eloquent
{
	protected $table = 'ruta_importador';
}
