<?php

class SiasPaisesOperacion extends Eloquent
{
	protected $table = 'sias_paises_operacion';
}
