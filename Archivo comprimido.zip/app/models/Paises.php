<?php

class Paises extends Eloquent
{
	protected $table = 'paises';
}
