<div class="lista-post-vertical"> 
	<p class="anuncios">
		<i class="fa fa-bullhorn"></i> ANUNCIOS
	</p>
	<div class="post-vertical">
		<div class="post-titulo">
			<img src="{{asset('images/pautas/logo1.png')}}">
			<h1>Sema Ltda</h1>
		</div>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut non, in minus molestias dolorum .</p>
		<img src="{{asset('images/pautas/empresa1.png')}}">
		<div class="clearfix"></div>
	</div>

	<div class="post-vertical">
		<div class="post-titulo">
			<img src="{{asset('images/pautas/logo2.png')}}">
			<h1>Construsite</h1>
		</div>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut non, in minus molestias dolorum .</p>
		<img src="{{asset('images/pautas/empresa2.png')}}">
		<div class="clearfix"></div>
	</div>

	<div class="post-vertical">
		<div class="post-titulo">
			<img src="{{asset('images/pautas/logo3.png')}}">
			<h1>Construsite Ltda</h1>
		</div>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut non, in minus molestias dolorum .</p>
		<img src="{{asset('images/pautas/empresa3.png')}}">
		<div class="clearfix"></div>
	</div>

</div>

@section('estilos')
@parent
{{HTML::style('css/pautas.css')}}
@stop


